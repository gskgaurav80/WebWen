-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 16, 2016 at 08:44 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `minor`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample3`
--

CREATE TABLE IF NOT EXISTS `tbl_sample3` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_sample3`
--

INSERT INTO `tbl_sample3` (`id`, `first_name`) VALUES
(2, 'home');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample4`
--

CREATE TABLE IF NOT EXISTS `tbl_sample4` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_sample4`
--

INSERT INTO `tbl_sample4` (`id`, `first_name`) VALUES
(4, 'content');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample5`
--

CREATE TABLE IF NOT EXISTS `tbl_sample5` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_sample5`
--

INSERT INTO `tbl_sample5` (`id`, `first_name`) VALUES
(5, 'about');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample6`
--

CREATE TABLE IF NOT EXISTS `tbl_sample6` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_sample6`
--

INSERT INTO `tbl_sample6` (`id`, `first_name`) VALUES
(6, 'god');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample7`
--

CREATE TABLE IF NOT EXISTS `tbl_sample7` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tbl_sample7`
--

INSERT INTO `tbl_sample7` (`id`, `first_name`) VALUES
(7, 'fplease');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample8`
--

CREATE TABLE IF NOT EXISTS `tbl_sample8` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_sample8`
--

INSERT INTO `tbl_sample8` (`id`, `first_name`) VALUES
(8, 'dkjl');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample9`
--

CREATE TABLE IF NOT EXISTS `tbl_sample9` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_sample9`
--

INSERT INTO `tbl_sample9` (`id`, `first_name`) VALUES
(9, 'qewwe');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample10`
--

CREATE TABLE IF NOT EXISTS `tbl_sample10` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `tbl_sample10`
--

INSERT INTO `tbl_sample10` (`id`, `first_name`) VALUES
(10, 'nkvo');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample11`
--

CREATE TABLE IF NOT EXISTS `tbl_sample11` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tbl_sample11`
--

INSERT INTO `tbl_sample11` (`id`, `first_name`) VALUES
(11, 'fdvdf');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample12`
--

CREATE TABLE IF NOT EXISTS `tbl_sample12` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tbl_sample12`
--

INSERT INTO `tbl_sample12` (`id`, `first_name`) VALUES
(12, 'fswfwe');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample13`
--

CREATE TABLE IF NOT EXISTS `tbl_sample13` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `tbl_sample13`
--

INSERT INTO `tbl_sample13` (`id`, `first_name`) VALUES
(13, 'sdfew');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample14`
--

CREATE TABLE IF NOT EXISTS `tbl_sample14` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `tbl_sample14`
--

INSERT INTO `tbl_sample14` (`id`, `first_name`) VALUES
(14, 'dvdsvfsd');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample15`
--

CREATE TABLE IF NOT EXISTS `tbl_sample15` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `tbl_sample15`
--

INSERT INTO `tbl_sample15` (`id`, `first_name`) VALUES
(15, 'dpolbfpd');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample16`
--

CREATE TABLE IF NOT EXISTS `tbl_sample16` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `tbl_sample16`
--

INSERT INTO `tbl_sample16` (`id`, `first_name`) VALUES
(16, 'bjkbjo');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample17`
--

CREATE TABLE IF NOT EXISTS `tbl_sample17` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `tbl_sample17`
--

INSERT INTO `tbl_sample17` (`id`, `first_name`) VALUES
(17, 'hbkjvk');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample18`
--

CREATE TABLE IF NOT EXISTS `tbl_sample18` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `tbl_sample18`
--

INSERT INTO `tbl_sample18` (`id`, `first_name`) VALUES
(18, 'bjhnoli');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample19`
--

CREATE TABLE IF NOT EXISTS `tbl_sample19` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `tbl_sample19`
--

INSERT INTO `tbl_sample19` (`id`, `first_name`) VALUES
(19, 'jkbphp');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample20`
--

CREATE TABLE IF NOT EXISTS `tbl_sample20` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `tbl_sample20`
--

INSERT INTO `tbl_sample20` (`id`, `first_name`) VALUES
(20, 'bnbnbn');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample21`
--

CREATE TABLE IF NOT EXISTS `tbl_sample21` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `tbl_sample21`
--

INSERT INTO `tbl_sample21` (`id`, `first_name`) VALUES
(21, 'kkkkkkkkkkk');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample22`
--

CREATE TABLE IF NOT EXISTS `tbl_sample22` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `tbl_sample22`
--

INSERT INTO `tbl_sample22` (`id`, `first_name`) VALUES
(22, 'pllll\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample23`
--

CREATE TABLE IF NOT EXISTS `tbl_sample23` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `tbl_sample23`
--

INSERT INTO `tbl_sample23` (`id`, `first_name`) VALUES
(23, 'oopof');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample24`
--

CREATE TABLE IF NOT EXISTS `tbl_sample24` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `tbl_sample24`
--

INSERT INTO `tbl_sample24` (`id`, `first_name`) VALUES
(24, 'dwscs');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample25`
--

CREATE TABLE IF NOT EXISTS `tbl_sample25` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `tbl_sample25`
--

INSERT INTO `tbl_sample25` (`id`, `first_name`) VALUES
(25, 'dsfcds');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample26`
--

CREATE TABLE IF NOT EXISTS `tbl_sample26` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `tbl_sample26`
--

INSERT INTO `tbl_sample26` (`id`, `first_name`) VALUES
(26, 'sdvvdsv');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample27`
--

CREATE TABLE IF NOT EXISTS `tbl_sample27` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `tbl_sample27`
--

INSERT INTO `tbl_sample27` (`id`, `first_name`) VALUES
(27, 'dsvsdsdv');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample28`
--

CREATE TABLE IF NOT EXISTS `tbl_sample28` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `tbl_sample28`
--

INSERT INTO `tbl_sample28` (`id`, `first_name`) VALUES
(28, 'jvcjv');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample29`
--

CREATE TABLE IF NOT EXISTS `tbl_sample29` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `tbl_sample29`
--

INSERT INTO `tbl_sample29` (`id`, `first_name`) VALUES
(29, 'kjn kb');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample30`
--

CREATE TABLE IF NOT EXISTS `tbl_sample30` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `tbl_sample30`
--

INSERT INTO `tbl_sample30` (`id`, `first_name`) VALUES
(30, 'viugiygiyu');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample31`
--

CREATE TABLE IF NOT EXISTS `tbl_sample31` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `tbl_sample31`
--

INSERT INTO `tbl_sample31` (`id`, `first_name`) VALUES
(31, 'bjvcujh');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample32`
--

CREATE TABLE IF NOT EXISTS `tbl_sample32` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `tbl_sample32`
--

INSERT INTO `tbl_sample32` (`id`, `first_name`) VALUES
(32, 'hjihujihyu');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sample33`
--

CREATE TABLE IF NOT EXISTS `tbl_sample33` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `tbl_sample33`
--

INSERT INTO `tbl_sample33` (`id`, `first_name`) VALUES
(33, 'bvhgcuy');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
