<?php  

 $connect = mysqli_connect("localhost", "root", "", "minor");  
 $sql = "DELETE FROM tbl_sample7 WHERE id = '".$_POST["id"]."'";  
 if(mysqli_query($connect, $sql))  
 {  
      echo 'Data Deleted';  
 }
		
 ?>  