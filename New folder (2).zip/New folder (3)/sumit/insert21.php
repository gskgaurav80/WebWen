<?php 

 $connect = mysqli_connect("localhost", "root", "", "minor");  
 $sql = "INSERT INTO tbl_sample21(first_name) VALUES('".$_POST["first_name"]."')";  
 if(mysqli_query($connect, $sql))  
 {  
      echo 'Data Inserted';  
 }  
		
		
 ?>  