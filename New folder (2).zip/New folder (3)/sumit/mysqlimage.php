<?php
     ini_set('mysql.connect_timeout',300);
	 ini_set('default_socket_timeout',300);



?>
<html>
  
    <body>
	<form method="post" enctype="multipart/form-data">
	<br/>
	   <input type="file" name="image" />
	   <br/><br/>
	   <input type="submit" name="sumit" value="upload" />
	  </form>
	  <?php
	     if(isset($_POST["submit"]))
		 {
			 if(getimagesize($FILES['image']['tmp_name'])==FALSE)
			 {
				 echo "BC image to select kar le.";
			 }
			 else
				 {
				 $image= addslashes($_FILES['image']['tmp_name']);
				 $name= addslashes($_FILES['image']['name']);
				 $image= file_get_contents($image);
				 $image= base64_encode($image);
				 saveimage($name,$image);
			     }
		 }
		 displayimage();
		 function saveimage($name,$image)
		 {
			 $con=mysqli_connect("localhost","root","","kstark");
			
			 $qry="insert into images (name,image) values ('$name','$image')";
			 $result=mysqli_query($qry,$con);
			 if($result)
			 {
				 echo "<br/>Image uploaded.";
			 }
			 else
			 {
				 echo "<br/>Image not uploaded.";
			 }	 
		 }
		 function displayimage()
		 {
			 $con=mysqli_connect("localhost","root","","kstark");
			 
			 $sql="select * from images;";
			 $result=mysqli_query($con,$sql);
			 if(mysqli_num_rows($result)>0)
		    {
			 while($row= mysqli_fetch_array($result))
			 {
				 echo '<img height="300" width="300" src="data:image;base64,'.$row[2].'">';
			 }
			}
			else
			
				echo " error";
			
			 mysqli_close($con);
			 
		 }
		 ?>
		 </body>
		 </html>