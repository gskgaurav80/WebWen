<?php  

 $connect = mysqli_connect("localhost", "root", "", "minor");  
 $sql = "DELETE FROM tbl_sample11 WHERE id = '".$_POST["id"]."'";  
 if(mysqli_query($connect, $sql))  
 {  
      echo 'Data Deleted';  
 }
		
 ?>  