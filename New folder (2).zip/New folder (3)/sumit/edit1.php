<?php 
 
        $connect = mysqli_connect("localhost", "root", "", "minor");  
        $id = $_POST["id"];  
        $text = $_POST["text"];  
        $column_name = $_POST["column_name"];  
        $sql = "UPDATE tbl_sample1 SET ".$column_name."='".$text."' WHERE id='".$id."'";  
         if(mysqli_query($connect, $sql))  
     {  
      echo 'Data Updated';  
 }
 
		
 ?>  