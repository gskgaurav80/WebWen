<?php  
 $connect = mysqli_connect("localhost", "root", "", "minor");  
 $output = '';  
 $sql = "SELECT * FROM tbl_sample27";  
 $result = mysqli_query($connect, $sql);  
 $output .= '  
      <div class="editable">  
           <table class="table table-bordered">  
                <tr>  
                       
                     <th width="40%"></th>  
                       
                     <th width="20%"></th>  
                </tr>';  
 if(mysqli_num_rows($result) > 0)  
 {  
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '  
                <tr>  
                       
                     <td class="first_name" data-id1="'.$row["id"].'" contenteditable>'.$row["first_name"].'</td>  
                     
                     <td><button type="button" name="delete_btn" data-id3="'.$row["id"].'" class="btn btn-xs btn-danger btn_delete">x</button></td>  
                </tr>  
           ';  
      }  
      $output .= '  
           <tr>  
                 
                <td id="first_name" contenteditable></td>  
                  
                <td><button type="button" name="btn_add" id="btn_add" class="btn btn-xs btn-success">+</button></td>  
           </tr>  
      ';  
 }  
 else  
 {  
      $output .= '<tr>  
                          <td colspan="4">Data not Found</td>  
                     </tr>';  
 }  
 $output .= '</table>  
      </div>';  
 echo $output;  
 ?>  