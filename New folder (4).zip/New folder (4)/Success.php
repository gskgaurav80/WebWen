<?php
$conn = new mysqli("localhost", "root", "","minorproject");
$user = $_POST["username"];
$password = $_POST["password"];
$password=mysql_escape_string($password);
$password=md5($password);
$password=substr($password, 0, -12);
echo "userhandle is:".$user;
echo "encrypted password is:         ".$password;
if(empty($user)||empty($password))
echo "Password required";
$sql_query = "select username,email,password from usersignup";
$res = $conn->query($sql_query);
$flag = 0;
while($row = $res->fetch_assoc())
{
	if(($row["username"] == $user && $row["password"] == $password) || ($row["email"] == $user && $row["password"] == $password))
		{
			$flag = 1;
			echo "Success";
			break;
		}
	else
		{
			//echo "hero";
		$flag = 0;
		}
	
}
if($flag == 1)
{
	header("Location:page2.html");
	}
	
else
  header("Location:wrong.html");

?>