<html>
<bodY>
<?php


$conn = new mysqli("localhost", "root", "","minorproject");
if($conn->connect_error)
{
	echo "fail connection";
}
$user = $_POST["username"];

$email = $_POST["emailsignup"];
$password = $_POST["pwd1"];
$password1 = $_POST["pwd2"];
$password=mysql_escape_string($password);
$password1=mysql_escape_string($password1);
$password=md5($password);
$password1=md5($password1);

echo "username is".$user;
echo "password is:".$password;
$vers = 0;
if($password!=$password1)
{ 
$vers=1;

	echo "Password not match";
}
else
{
$vers=0;
$query = "insert into usersignup values('$user','$email','$password')";
 
$conn->query($query);
}
if($vers==0)
{
header("Location:page1.html");
}
else
{
	//echo '<script language="javascript">'; echo 'alert("your password did not match")'; echo '</script>'; exit;
	header("Location:LoginTry22.html");

 

}
?>

