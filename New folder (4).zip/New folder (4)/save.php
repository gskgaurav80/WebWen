<?php
// Receive form Post data and Saving it in variables

$name = @$_POST['name'];
$email = @$_POST['email'];
$comment = @$_POST['comment'];

// Write the name of text file where data will be store
$filename = "mydata.txt";

// Marge all the variables with text in a single variable. 
$f_data= '
Name : '.$name.'
Email :  '.$email.'
Comments: '.$comment.'  
==============================================================================
';





header("Location:page1.html");
$file = fopen($filename, "w");
fwrite($file,$f_data);
fclose($file);
?>